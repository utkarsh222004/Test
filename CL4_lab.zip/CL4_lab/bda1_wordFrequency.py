# import multiprocessing
# import re
# from collections import Counter

# # Function to read input file
# def read_file(filename):
#     with open(filename, 'r', encoding='utf-8') as f:
#         return f.read()

# # Mapper function to count word occurrences in each chunk
# def word_frequency_mapper(args):
#     text_chunk, target_word = args
#     words = re.findall(r'\b\w+\b', text_chunk.lower())  # Extract full words
#     return Counter(words)[target_word]  # Count target word

# # Reducer function to sum up all partial counts
# def reducer(counts_list):
#     return sum(counts_list)

# # Function to split text into chunks
# def split_text_into_chunks(text, num_chunks):
#     words = re.findall(r'\b\w+\b', text)  # Extract words
#     num_chunks = min(num_chunks, len(words))  # Ensure valid chunk count
#     chunk_size = max(1, len(words) // num_chunks)  # Avoid zero chunk_size

#     chunks = [" ".join(words[i:i + chunk_size]) for i in range(0, len(words), chunk_size)]
#     return chunks

# # Main MapReduce Function
# def mapreduce(filename, target_word):
#     text = read_file(filename)
#     num_workers = min(multiprocessing.cpu_count(), len(text))  # Set a reasonable worker count
#     chunks = split_text_into_chunks(text, num_workers)  # Create chunks
    
#     with multiprocessing.Pool(processes=num_workers) as pool:
#         mapped_results = pool.map(word_frequency_mapper, [(chunk, target_word) for chunk in chunks])
    
#     return reducer(mapped_results)

# if __name__ == "__main__":
#     filename = "word_frequency.txt"  # Change this to your text file
#     target_word = "mapreduce"  # Change this to the word you want to count

#     # Calculate word frequency using MapReduce
#     word_frequency = mapreduce(filename, target_word.lower())

#     print(f"Frequency of '{target_word}': {word_frequency}")


# ------------------------------------------------------------------------------------
# !/usr/bin/env python

import sys
from operator import itemgetter

class WordFrequencyMapper:
    def __init__(self, target_word):
        self.target_word = target_word.lower()
    
    def map(self):
        # Input comes from standard input (stdin)
        for line in sys.stdin:
            # Remove leading and trailing whitespace
            line = line.strip()
            # Split the line into words
            words = line.split()
            
            # For each word, emit a key-value pair with the word as the key
            # and 1 as the value only if it matches our target word
            for word in words:
                # Convert to lowercase to make comparison case-insensitive
                word = word.lower()
                if word == self.target_word:
                    print('%s\t%s' % (word, 1))

class WordFrequencyReducer:
    def reduce(self):
        current_word = None
        current_count = 0
        word = None

        # Input comes from standard input (stdin)
        for line in sys.stdin:
            # Remove leading and trailing whitespace
            line = line.strip()
            
            # Parse the input from mapper
            word, count = line.split('\t', 1)
            
            # Convert count to integer
            try:
                count = int(count)
            except ValueError:
                # Count was not a number, so silently ignore this line
                continue
            
            # This IF-switch works because Hadoop sorts map output by key
            # before it is passed to the reducer
            if current_word == word:
                current_count += count
            else:
                if current_word:
                    # Write result to standard output
                    print('%s\t%s' % (current_word, current_count))
                current_count = count
                current_word = word
        
        # Don't forget to output the last word if needed
        if current_word == word:
            print('%s\t%s' % (current_word, current_count))

# Main function to execute the mapper or reducer based on command line args
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python word_frequency.py [mapper|reducer] [target_word]")
        sys.exit(1)
    
    mode = sys.argv[1]
    
    if mode == "mapper":
        if len(sys.argv) < 3:
            print("Mapper mode requires a target word")
            sys.exit(1)
        target_word = sys.argv[2]
        mapper = WordFrequencyMapper(target_word)
        mapper.map()
    elif mode == "reducer":
        reducer = WordFrequencyReducer()
        reducer.reduce()
    else:
        print("Invalid mode. Use 'mapper' or 'reducer'")
        sys.exit(1)


# -------------------------------------------------------------------
# Commands
'''
hadoop jar C:\hadoop\share\hadoop\tools\lib\hadoop-streaming-3.2.4.jar ^
-files bda1_wordFrequency.py ^
-mapper "python bda1_wordFrequency.py mapper mapreduce" ^
-reducer "python bda1_wordFrequency.py reducer" ^
-input file:///C:/Users/Saiashish/Desktop/BE-4th_Year/Sem_8/CL4_lab/word_frequency.txt ^
-output file:///C:/Users/Saiashish/Desktop/BE-4th_Year/Sem_8/CL4_lab/output-word

to print output run below command
type C:\Users\Saiashish\Desktop\BE-4th_Year\Sem_8\CL4_lab\output-word\part-00000

'''