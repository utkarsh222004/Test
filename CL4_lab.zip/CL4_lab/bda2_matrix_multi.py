# import multiprocessing
# import numpy as np

# # Function to take matrix input from user
# def input_matrix(rows, cols, name):
#     print(f"Enter matrix {name} ({rows}x{cols}):")
#     matrix = []
#     for i in range(rows):
#         row = list(map(int, input(f"Row {i + 1}: ").split()))
#         if len(row) != cols:
#             raise ValueError(f"Each row must have {cols} elements!")
#         matrix.append(row)
#     return np.array(matrix)

# # Mapper function to compute partial dot products
# def matrix_multiply_mapper(args):
#     row, B = args  # Unpack row of A and matrix B
#     return [sum(a * b for a, b in zip(row, col)) for col in zip(*B)]  # Compute row of C

# # Reducer function to collect results
# def matrix_multiply_reducer(results):
#     return np.array(results)

# # MapReduce function for matrix multiplication
# def mapreduce_matrix_multiplication(A, B):
#     num_workers = min(multiprocessing.cpu_count(), len(A))  # Define parallel workers

#     with multiprocessing.Pool(processes=num_workers) as pool:
#         mapped_results = pool.map(matrix_multiply_mapper, [(row, B) for row in A])

#     return matrix_multiply_reducer(mapped_results)

# if __name__ == "__main__":
#     # Take matrix dimensions as input
#     ROWS_A = int(input("Enter number of rows for Matrix A: "))
#     COLS_A = int(input("Enter number of columns for Matrix A: "))
#     ROWS_B = int(input("Enter number of rows for Matrix B: "))
#     COLS_B = int(input("Enter number of columns for Matrix B: "))

#     # Ensure matrix dimensions are valid for multiplication (COLS_A == ROWS_B)
#     if COLS_A != ROWS_B:
#         raise ValueError("Matrix multiplication not possible! Number of columns in A must match rows in B.")

#     # Take matrix input from the user
#     A = input_matrix(ROWS_A, COLS_A, "A")
#     B = input_matrix(ROWS_B, COLS_B, "B")

#     print("\nMatrix A:")
#     print(A)
#     print("\nMatrix B:")
#     print(B)

#     # Perform MapReduce-based matrix multiplication
#     C = mapreduce_matrix_multiplication(A, B)

#     print("\nResultant Matrix C (A x B):")
#     print(C)

# ------------------------------------------------------------------------------------
#!/usr/bin/env python3

import sys
import os

# Mapper script
def mapper():
    # Read environment variables or use defaults
    i_max = int(os.environ.get('i_max', 3))
    k_max = int(os.environ.get('k_max', 3))
    
    for line in sys.stdin:
        # Parse input line
        line = line.strip()
        if not line:
            continue
        
        parts = line.split(',')
        matrix = parts[0]
        
        if matrix == 'A':
            # A,i,j,value
            _, i, j, value = parts
            i, j = int(i), int(j)
            value = float(value)
            
            # Emit for each possible k
            for k in range(k_max):
                print(f"{i},{k}\tA,{j},{value}")
                
        elif matrix == 'B':
            # B,j,k,value
            _, j, k, value = parts
            j, k = int(j), int(k)
            value = float(value)
            
            # Emit for each possible i
            for i in range(i_max):
                print(f"{i},{k}\tB,{j},{value}")

# Reducer script
def reducer():
    current_key = None
    a_values = {}
    b_values = {}
    
    # Read j_max from environment variables or use default
    j_max = int(os.environ.get('j_max', 2))
    
    for line in sys.stdin:
        # Parse input
        line = line.strip()
        if not line:
            continue
        
        key, value = line.split('\t', 1)
        matrix, j, val = value.split(',')
        j = int(j)
        val = float(val)
        
        # If key changes, process the previous key
        if current_key and current_key != key:
            # Calculate result for previous key
            result = 0
            for j in range(j_max):
                result += a_values.get(j, 0) * b_values.get(j, 0)
            
            if result != 0:
                print(f"{current_key}\t{result}")
            
            # Reset for new key
            a_values = {}
            b_values = {}
        
        current_key = key
        
        # Store value
        if matrix == 'A':
            a_values[j] = a_values.get(j, 0) + val
        else:  # matrix == 'B'
            b_values[j] = b_values.get(j, 0) + val
    
    # Process the last key
    if current_key:
        result = 0
        for j in range(j_max):
            result += a_values.get(j, 0) * b_values.get(j, 0)
        
        if result != 0:
            print(f"{current_key}\t{result}")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--mapper":
        mapper()
    elif len(sys.argv) > 1 and sys.argv[1] == "--reducer":
        reducer()
    else:
        # Simulate MapReduce locally for testing
        print("This script is designed to be used with Hadoop Streaming.")
        print("For local testing, pipe input through mapper and reducer:")
        print("cat matrix_data.txt | python3 matrix_multiplication.py --mapper | sort | python3 matrix_multiplication.py --reducer")

# -------------------------------------------------------------------
# Commands
'''
hadoop jar C:\hadoop\share\hadoop\tools\lib\hadoop-streaming-3.2.4.jar ^
More? -files bda2_matrix_multi.py ^
More? -mapper "python bda2_matrix_multi.py --mapper" ^
More? -reducer "python bda2_matrix_multi.py --reducer" ^
More? -input file:///C:/Users/ADMIN/OneDrive/Documents/CL4/bda3/input/matrix_data.txt ^
More? -output file:///C:/Users/ADMIN/OneDrive/Documents/CL4/bda3/output-matrix ^
More? -cmdenv "i_max=3" -cmdenv "j_max=2" -cmdenv "k_max=3"

to print output run below command
type C:\Users\ADMIN\OneDrive\Documents\CL4\bda3\output-matrix\part-00000
'''