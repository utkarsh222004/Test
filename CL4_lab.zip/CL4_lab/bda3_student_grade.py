# import multiprocessing

# # Function to take student data input
# def input_students():
#     num_students = int(input("Enter number of students: "))
#     students = []
#     for _ in range(num_students):
#         name = input("Enter student name: ")
#         marks = float(input(f"Enter marks for {name}: "))
#         students.append((name, marks))
#     return students

# # Mapper function - Assigns grades based on marks
# def grade_mapper(student):
#     name, marks = student
#     if marks >= 90:
#         grade = "A+"
#     elif marks >= 80:
#         grade = "A"
#     elif marks >= 70:
#         grade = "B"
#     elif marks >= 60:
#         grade = "C"
#     elif marks >= 50:
#         grade = "D"
#     else:
#         grade = "F"
#     return (name, grade)

# # Reducer function - Collects results into a dictionary
# def grade_reducer(mapped_results):
#     return dict(mapped_results)

# # MapReduce function
# def mapreduce_student_grades(students):
#     num_workers = min(multiprocessing.cpu_count(), len(students))

#     with multiprocessing.Pool(processes=num_workers) as pool:
#         mapped_results = pool.map(grade_mapper, students)

#     return grade_reducer(mapped_results)

# if __name__ == "__main__":
#     # Input student data
#     students = input_students()

#     print("\nCalculating Grades...\n")
    
#     # Compute grades using MapReduce
#     student_grades = mapreduce_student_grades(students)

#     # Display results
#     print("Student Grades:")
#     for student, grade in student_grades.items():
#         print(f"{student}: {grade}")


# ------------------------------------------------------------------------------------
#!/usr/bin/env python3

import sys
import os

# Mapper function
def mapper():
    """
    Mapper reads student records and emits (student_id, score) pairs
    Input format expected: student_id,subject,score
    """
    for line in sys.stdin:
        # Remove leading/trailing whitespace and split the line
        line = line.strip()
        if not line:
            continue
            
        # Parse the input
        fields = line.split(',')
        if len(fields) != 3:
            # Skip malformed input
            continue
            
        student_id, subject, score = fields
        
        try:
            # Validate score is a number
            score = float(score)
            # Emit student_id as key and score as value
            print(f"{student_id}\t{score}")
        except ValueError:
            # Skip records with invalid scores
            continue

# Reducer function
def reducer():
    """
    Reducer processes scores for each student and assigns a grade
    Output: student_id, average_score, grade
    """
    current_student = None
    scores = []
    
    # Grade boundaries
    def get_grade(avg_score):
        if avg_score >= 90:
            return 'A'
        elif avg_score >= 80:
            return 'B'
        elif avg_score >= 70:
            return 'C'
        elif avg_score >= 60:
            return 'D'
        else:
            return 'F'
    
    for line in sys.stdin:
        # Remove leading/trailing whitespace and split the line
        line = line.strip()
        if not line:
            continue
            
        # Parse the input (student_id, score)
        student_id, score = line.split('\t')
        score = float(score)
        
        # If we encounter a new student, process the previous one
        if current_student and current_student != student_id:
            # Calculate average score
            avg_score = sum(scores) / len(scores)
            # Determine grade
            grade = get_grade(avg_score)
            # Output: student_id, average_score, grade
            print(f"{current_student}\t{avg_score:.2f}\t{grade}")
            
            # Reset for the new student
            scores = []
        
        # Update current student and add score to the list
        current_student = student_id
        scores.append(score)
    
    # Process the last student
    if current_student:
        avg_score = sum(scores) / len(scores)
        grade = get_grade(avg_score)
        print(f"{current_student}\t{avg_score:.2f}\t{grade}")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--mapper":
        mapper()
    elif len(sys.argv) > 1 and sys.argv[1] == "--reducer":
        reducer()
    else:
        # Simulate MapReduce locally for testing
        print("This script is designed to be used with Hadoop Streaming.")
        print("For local testing, pipe input through mapper and reducer:")
        print("cat student.txt | python3 bda3_student_grade.py --mapper | sort | python3 bda3_student_grade.py --reducer")

# -------------------------------------------------------------------
# Commands
'''
hadoop jar C:\hadoop\share\hadoop\tools\lib\hadoop-streaming-3.2.4.jar ^
-files bda3_student_grade.py ^
-mapper "python bda3_student_grade.py --mapper" ^
-reducer "python bda3_student_grade.py --reducer" ^
-input file:///C:/Users/Saiashish/Desktop/BE-4th_Year/Sem_8/CL4_lab/student.txt ^
-output file:///C:/Users/Saiashish/Desktop/BE-4th_Year/Sem_8/CL4_lab/output-grades

to print output run below command
type C:\Users\Saiashish\Desktop\BE-4th_Year\Sem_8\CL4_lab\output-grades\part-00000
'''
