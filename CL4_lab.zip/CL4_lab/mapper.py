#!/usr/bin/env python3
import sys

for line in sys.stdin:
    name, marks = line.strip().split(',')
    marks = float(marks)
    if marks >= 90:
        grade = "A+"
    elif marks >= 80:
        grade = "A"
    elif marks >= 70:
        grade = "B"
    elif marks >= 60:
        grade = "C"
    elif marks >= 50:
        grade = "D"
    else:
        grade = "F"
    print(f"{name}\t{grade}")